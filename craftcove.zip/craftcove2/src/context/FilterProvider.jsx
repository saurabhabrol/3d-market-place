import React, { createContext, useContext } from "react";

export const FilterContext = createContext({});

const filters = ["All","Art", "Home", "Fashion", "Decorations", "Engineering"];
export default function FilterProvider({ children }) {
  const [allFilters, setAllFilters] = React.useState(filters);
  const [selectedFilter, setSelectedFilter] = React.useState(filters[0]);
  

  return (
    <FilterContext.Provider
      value={{
        setSelectedFilter,
        selectedFilter,
        setAllFilters,
        allFilters,
      }}
    >
      {children}
    </FilterContext.Provider>
  );
}

export const useFilter = () => useContext(FilterContext);