import React, { createContext, useContext } from "react";

export const CartContext = createContext({});

export default function CartProvider({ children }) {
  const [cartItems, setCartItems] = React.useState([]);
  const [totalPrice, setTotalPrice] = React.useState(0.0);
  const [isCartOpen, setIsCartOpen] = React.useState(false)
  const [uploads, setUploads] = React.useState([])
  const addItem = (product, image, color) => {
    const findProduct = cartItems.find(
      (item) => item.id.toString() === product.id.toString()
    );
    if (findProduct) {
      setCartItems((prev) =>
        prev.map((item) =>
          item.id.toString() === product.id.toString()
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      );
      setTotalPrice((prev) => prev + product.price);
    } else {
      setCartItems((prev) => [
        ...prev,
        { ...product, image: image, quantity: 1, color: color },
      ]);
      setTotalPrice((prev) => prev + product.price);
    }
  };
  const removeItem = (id) => {
    const productToRemove = cartItems.find((item) => item.id.toString() === id.toString());
    if (productToRemove) {
      if (productToRemove.quantity === 1) {
        // If quantity is 1, remove the item completely
        setCartItems((prev) => prev.filter((item) => item.id !== id));
      } else {
        // Reduce quantity by 1
        setCartItems((prev) =>
          prev.map((item) =>
            item.id === id ? { ...item, quantity: item.quantity - 1 } : item
          )
        );
      }
      setTotalPrice((prev) => prev - productToRemove.price);
    }
  };

  return (
    <CartContext.Provider
      value={{
        cartItems,
        setCartItems,
        addItem,
        setTotalPrice,
        removeItem,
        totalPrice,
        setIsCartOpen,
        setUploads,
        uploads,
        isCartOpen
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);