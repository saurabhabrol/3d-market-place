import SaleBanner from "./components/SaleBanner";
import Filters from "./components/Filters";
import Products from "./components/Products";
import Navbar from "./components/Navbar";
import { Outlet } from "react-router";
import Carousel from "./components/Carousel";

export default function App() {
  return (
    <div className="flex flex-col gap-6 sm:gap-12">
      <Navbar />
      <div className="px-2 sm:px-20">
        <Outlet />
      </div>
    </div>
  );
}
const slides = [
  {
    line: "Handcrafted sculpture statue for your Home.",
    quote: "Sculpture Statue",
    url: "https://unsplash.com/photos/EF1nSXZCzcM/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxTY3VscHR1cmUlMjBTdGF0dWV8ZW58MHx8fHwxNzE0NDYxOTUzfDA",
  },
  {
    line: "Soft decorative throw pillow for your couch.",
    quote: "Decorative Throw Pillow",
    url: "https://unsplash.com/photos/Y9iAaT2my2I/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxEZWNvcmF0aXZlJTIwVGhyb3clMjBQaWxsb3d8ZW58MHx8fHwxNzE0NDYxOTUzfDA",
  },
  {
    line: "Modern decorative wall mirror for your hallway.",
    quote: "Decorative Wall Mirror",
    url: "https://unsplash.com/photos/Hwu3vwDEorM/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxEZWNvcmF0aXZlJTIwV2FsbCUyME1pcnJvcnxlbnwwfHx8fDE3MTQ0NjE5NTN8MA",
  },
  {
    line: "Cozy throw blanket for chilly nights.",
    quote: "Throw Blanket",
    url: "https://unsplash.com/photos/53BjYSxca5g/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxUaHJvdyUyMEJsYW5rZXR8ZW58MHx8fHwxNzE0NDYxOTUzfDA",
  },
];

export const Ant = () => {
  return (
    <>
      <Carousel slides={slides} />
      <div>
        <Filters />
      </div>
      <Products />
    </>
  );
};
