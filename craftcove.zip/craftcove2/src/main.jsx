import React from "react";
import ReactDOM from "react-dom/client";
import App, { Ant } from "./App.jsx";
import "./index.css";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import BuyProduct from "./components/BuyProduct.jsx";
import CartProvider from "./context/CartProvider.jsx";
import FilterProvider from "./context/FilterProvider.jsx";
import NavigateProducts from "./components/NavigateProducts.jsx";
import CategoryProduct from "./components/CategoryProduct.jsx";
import MainProducts from "./components/MainProducts.jsx";
import Login from "./components/Login.jsx";
import Register from "./components/Register.jsx";
import Profile from "./components/Profile.jsx";
import Orders from "./components/Orders.jsx";
import Uploads from "./components/Uploads.jsx";
import UploadProduct from "./components/UploadProduct.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <CartProvider>
      <FilterProvider>
        <main >
          <RouterProvider
            router={createBrowserRouter([
              {
                path: "/",
                element: <App />,
                children: [
                  {
                    index: true,
                    element: <Ant />,
                  },
                  {
                    path: "/products",
                    element: <MainProducts />,
                    children: [
                      {
                        index: true,
                        element: <NavigateProducts />,
                      },
                      {
                        path: "/products/:productId",
                        element: <BuyProduct />,
                      },
                      {
                        path: "/products/categories/:category",
                        element: <CategoryProduct />,
                      },
                    ],
                  },
                ],
              },
              {
                path: "/login",
                element: <Login />,
              },
              {
                path: "/register",
                element: <Register />,
              },
              {
                path: "/profile",
                element: <Profile />,
              },
              {
                path: "/orders",
                element: <Orders />,
              },
              {
                path: "/uploads",
                element: <Uploads />,
              },
              {
                path: "/uploadproduct",
                element: <UploadProduct />,
              },
            ])}
          />
        </main>
      </FilterProvider>
    </CartProvider>
  </React.StrictMode>
);
