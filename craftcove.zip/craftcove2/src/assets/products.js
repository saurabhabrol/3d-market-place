export const products = [
    // Art
    {
      id: 1,
      name: "Abstract Canvas Art",
      description: "Vibrant abstract canvas art for your living room.",
      category: "Art",
      image: "https://unsplash.com/photos/5NE6mX0WVfQ/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxBYnN0cmFjdCUyMENhbnZhcyUyMEFydHxlbnwwfHx8fDE3MTQ0NjE5NTR8MA",
      price: 49.99,
      colors: ["Red", "Blue", "Yellow", "Green"],
      rating: 4.5
    },
    {
      id: 2,
      name: "Sculpture Statue",
      description: "Handcrafted sculpture statue for your Home.",
      category: "Art",
      image: "https://unsplash.com/photos/EF1nSXZCzcM/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxTY3VscHR1cmUlMjBTdGF0dWV8ZW58MHx8fHwxNzE0NDYxOTUzfDA",
      price: 79.99,
      colors: ["gray", "#cd7f32", "#ffd700"],
      rating: 2.8
    },
    {
      id: 3,
      name: "Oil Painting",
      description: "Classic oil painting on canvas.",
      category: "Art",
      image: "https://unsplash.com/photos/kiLdjFm2y14/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxPaWwlMjBQYWludGluZ3xlbnwwfHx8fDE3MTQ0NjE5NTN8MA",
      price: 99.99,
      colors: undefined,
      rating: 4.7
    },
    {
      id: 4,
      name: "Framed Art Print",
      description: "High-quality framed art print for your office space.",
      category: "Art",
      image: "https://unsplash.com/photos/_Yc7OtfFn-0/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxGcmFtZWQlMjBBcnQlMjBQcmludHxlbnwwfHx8fDE3MTQ0NjE5NTN8MA",
      price: 29.99,
      colors: ["Black", "yellow", "Brown"],
      rating: 3.6
    },
    {
      id: 5,
      name: "Watercolor Sketch Set",
      description: "Professional watercolor sketch set with a variety of colors.",
      category: "Art",
      image: "https://images.unsplash.com/photo-1554938521-9e0763797568?q=80&w=1887&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      price: 19.99,
      colors: undefined,
      rating: 4.4
    },
  
    // Home
    {
      id: 6,
      name: "Decorative Throw Pillow",
      description: "Soft decorative throw pillow for your couch.",
      category: "Home",
      image: "https://unsplash.com/photos/Y9iAaT2my2I/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxEZWNvcmF0aXZlJTIwVGhyb3clMjBQaWxsb3d8ZW58MHx8fHwxNzE0NDYxOTUzfDA",
      price: 14.99,
      colors: ["Blue", "Green", "Pink"],
      rating: 4.3
    },
    {
      id: 7,
      name: "Wall Clock",
      description: "Elegant wall clock for your living room.",
      category: "Home",
      image: "https://unsplash.com/photos/1RGvrDGu9kA/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxXYWxsJTIwQ2xvY2t8ZW58MHx8fHwxNzE0NDYxOTUzfDA",
      price: 39.99,
      colors: ["#c0c0c0", "Gold", "Black"],
      rating: 4.9
    },
    {
      id: 8,
      name: "Ceramic Vase",
      description: "Minimalist ceramic vase for your flower arrangements.",
      category: "Home",
      image: "https://unsplash.com/photos/YP4NILq7qFo/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxDZXJhbWljJTIwVmFzZXxlbnwwfHx8fDE3MTQ0NjE5NTN8MA",
      price: 24.99,
      colors: ["brown", "Grey"],
      rating: 4.6
    },
    {
      id: 9,
      name: "Decorative Wall Mirror",
      description: "Modern decorative wall mirror for your hallway.",
      category: "Home",
      image: "https://unsplash.com/photos/Hwu3vwDEorM/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxEZWNvcmF0aXZlJTIwV2FsbCUyME1pcnJvcnxlbnwwfHx8fDE3MTQ0NjE5NTN8MA",
      price: 49.99,
      colors: ["Gold", "Black"],
      rating: 4.7
    },
    {
      id: 10,
      name: "Accent Rug",
      description: "Stylish accent rug for your bedroom or living room.",
      category: "Home",
      image: "https://unsplash.com/photos/25Gx85b0r94/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxBY2NlbnQlMjBSdWd8ZW58MHx8fHwxNzE0NDYxOTUzfDA",
      price: 34.99,
      colors: ["Grey", "brown"],
      rating: 4.5
    },
  
    // Decor
    {
      id: 11,
      name: "Decorative Plant Pot",
      description: "Decorative plant pot for your indoor plants.",
      category: "Decorations",
      image: "https://unsplash.com/photos/TpeR5Im-gHM/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxEZWNvcmF0aXZlJTIwUGxhbnQlMjBQb3R8ZW58MHx8fHwxNzE0NDYxOTU0fDA",
      price: 19.99,
      colors: ["brown", "lightgray", "Black"],
      rating: 3.4
    },
    {
      id: 12,
      name: "Table Lamp",
      description: "Sleek table lamp for your bedside table.",
      category: "Decorations",
      image: "https://unsplash.com/photos/AgU9-qsNc1Y/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxUYWJsZSUyMExhbXB8ZW58MHx8fHwxNzE0NDYxOTUzfDA",
      price: 29.99,
      colors: ["Gold", "#c0c0c0", "Black"],
      rating: 4.8
    },
    {
      id: 13,
      name: "Candle Holder Set",
      description: "Set of decorative candle holders for your dining table.",
      category: "Decorations",
      image: "https://unsplash.com/photos/zqLhBielEZw/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxDYW5kbGUlMjBIb2xkZXIlMjBTZXR8ZW58MHx8fHwxNzE0NDYxOTUzfDA",
      price: 19.99,
      colors: ["#b5a642", "#c0c0c0"],
      rating: 2.6
    },
    {
      id: 14,
      name: "Wall Art Decal",
      description: "Removable wall art decal to add a touch of creativity to your space.",
      category: "Decorations",
      image: "https://unsplash.com/photos/Hh_pjZCpXEk/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxXYWxsJTIwQXJ0JTIwRGVjYWx8ZW58MHx8fHwxNzE0NDYxOTU0fDA",
      price: 9.99,
      colors: ["Black", "gray"],
      rating: 4.3
    },
    {
      id: 15,
      name: "Throw Blanket",
      description: "Cozy throw blanket for chilly nights.",
      category: "Decorations",
      image: "https://unsplash.com/photos/53BjYSxca5g/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxUaHJvdyUyMEJsYW5rZXR8ZW58MHx8fHwxNzE0NDYxOTUzfDA",
      price: 29.99,
      colors: ["Grey", "f5f5dc", "#000080"],
      rating: 4.7
    },
  
    // Engineering
    {
      id: 16,
      name: "Mechanical Keyboard",
      description: "High-performance mechanical keyboard for gaming and typing.",
      category: "Engineering",
      image: "https://unsplash.com/photos/8ssNFn4VPLg/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxNZWNoYW5pY2FsJTIwS2V5Ym9hcmR8ZW58MHx8fHwxNzE0NDYxOTUzfDA",
      price: 99.99,
      colors: ["Black", "White"],
      rating: 3.9
    },
    {
      id: 17,
      name: "3D Printer Filament",
      description: "Premium PLA filament for 3D printing projects.",
      category: "Engineering",
      image: "https://unsplash.com/photos/NMCABEhN0RE/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHwzRCUyMFByaW50ZXIlMjBGaWxhbWVudHxlbnwwfHx8fDE3MTQ0NjE5NTN8MA",
      price: 24.99,
      colors: ["Red", "Blue", "Black"],
      rating: 4.5
    },
    {
      id: 18,
      name: "Arduino Starter Kit",
      description: "Beginner-friendly Arduino starter kit for electronics projects.",
      category: "Engineering",
      image: "https://unsplash.com/photos/gavODTHG36Y/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxBcmR1aW5vJTIwU3RhcnRlciUyMEtpdHxlbnwwfHx8fDE3MTQ0NjE5NTN8MA",
      price: 49.99,
      colors: undefined,
      rating: 2.7
    },
    {
      id: 19,
      name: "Toolbox Set",
      description: "Comprehensive toolbox set for DIY enthusiasts.",
      category: "Engineering",
      image: "https://unsplash.com/photos/VdOO4_HFTWM/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxUb29sYm94JTIwU2V0fGVufDB8fHx8MTcxNDQ2MTk1M3ww",
      price: 79.99,
      colors: ["Red", "Black"],
      rating: 4.6
    },
    {
      id: 20,
      name: "Soldering Iron Kit",
      description: "Professional soldering iron kit for soldering electronics.",
      category: "Engineering",
      image: "https://unsplash.com/photos/CJeNJMAUmpU/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxTb2xkZXJpbmclMjBJcm9uJTIwS2l0fGVufDB8fHx8MTcxNDQ2MTk1M3ww",
      price: 34.99,
      colors: ["Blue", "#c0c0c0"],
      rating: 4.8
    },
  
    // Fashion
    {
      id: 21,
      name: "Graphic T-shirt",
      description: "Stylish graphic t-shirt for casual wear.",
      category: "Fashion",
      image: "https://unsplash.com/photos/TT-ROxWj9nA/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxHcmFwaGljJTIwVC1zaGlydHxlbnwwfHx8fDE3MTQ0NjE5NTN8MA",
      price: 19.99,
      colors: ["Black", "White", "Grey"],
      rating: 4.6
    },
    {
      id: 22,
      name: "Denim Jacket",
      description: "Classic denim jacket for versatile styling.",
      category: "Fashion",
      image: "https://unsplash.com/photos/_BDBEP0ePQc/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxEZW5pbSUyMEphY2tldHxlbnwwfHx8fDE3MTQ0NjE5NTN8MA",
      price: 59.99,
      colors: ["Blue"],
      rating: 4.7
    },
    {
      id: 23,
      name: "Leather Wallet",
      description: "Genuine leather wallet with multiple card slots.",
      category: "Fashion",
      image: "https://unsplash.com/photos/GTmLKWZzZuo/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxMZWF0aGVyJTIwV2FsbGV0fGVufDB8fHx8MTcxNDQ2MTk1M3ww",
      price: 29.99,
      colors: ["Brown", "Black"],
      rating: 1.5
    },
    {
      id: 24,
      name: "Designer Sunglasses",
      description: "Trendy designer sunglasses for UV protection.",
      category: "Fashion",
      image: "https://unsplash.com/photos/Nv4QHkTVEaI/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxEZXNpZ25lciUyMFN1bmdsYXNzZXN8ZW58MHx8fHwxNzE0NDYxOTUzfDA",
      price: 79.99,
      colors: ["Black", "brown", "Gold"],
      rating: 4.8
    },
    {
      id: 25,
      name: "Canvas Backpack",
      description: "Sturdy canvas backpack for everyday use.",
      category: "Fashion",
      image: "https://unsplash.com/photos/5pujJ6JNWXU/download?ixid=M3w1OTUxODh8MHwxfHNlYXJjaHwxfHxDYW52YXMlMjBCYWNrcGFja3xlbnwwfHx8fDE3MTQ0NjE5NTN8MA",
      price: 39.99,
      colors: ["Black", "Grey", "#000080"],
      rating: 3.4
    },
  ];
  