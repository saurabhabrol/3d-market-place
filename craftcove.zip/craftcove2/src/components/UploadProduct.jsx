import React, { useState } from "react";
import Navbar from "./Navbar";
import { useNavigate } from "react-router-dom";
import { useCart } from "@/context/CartProvider";

export default function UploadProduct() {
  const [selectedFile, setSelectedFile] = useState(null);
  const navigate = useNavigate();
  const [previewUrl, setPreviewUrl] = useState(null);
  const [fileName, setFileName] = useState();
  const { setUploads } = useCart();

  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    // Check if file is an image
    if (file && file.type.startsWith("image/")) {
      setSelectedFile(file);
      setFileName(file.name.split(".")[0]);
      const reader = new FileReader();
      reader.addEventListener("load", () => {
        setPreviewUrl(reader.result);
      });
      reader.readAsDataURL(file);
    } else {
      setSelectedFile(null);
      setPreviewUrl(null);
      alert("Please select a valid image file.");
    }
  };

  const handleDragOver = (event) => {
    event.preventDefault();
  };

  const handleDrop = (event) => {
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    // Check if dropped file is an image
    if (file && file.type.startsWith("image/")) {
      setSelectedFile(file);
      setFileName(file.name.split(".")[0]);
      const reader = new FileReader();
      reader.addEventListener("load", () => {
        setPreviewUrl(reader.result);
      });
      reader.readAsDataURL(file);
    } else {
      setSelectedFile(null);
      setPreviewUrl(null);
      alert("Please drop a valid image file.");
    }
  };

  const handleUpload = () => {
    const data = {
      name: fileName,
      file: previewUrl,
    };
    const prev = JSON.parse(localStorage.getItem("uploads")) || [];
    localStorage.setItem("uploads", JSON.stringify([...prev, data]));
    setUploads((prev) => [...prev, data]);
    navigate("/uploads");
  };

  React.useEffect(() => {
    if (!localStorage.getItem("isLoggedIn")) {
      navigate("/login");
    }
  }, []);

  return (
    <div>
      <Navbar />
      <div className="my-10 px-3">
        <strong className="text-3xl">Upload file</strong>
        {selectedFile ? (
          <div className="mt-4 flex gap-8 sm:flex-row flex-col">
            <img
              src={previewUrl}
              alt="Preview"
              className="sm:h-[400px] aspect-square rounded-xl object-cover"
            />
            <div className="flex flex-col">
              <strong className="text-xl">{selectedFile.name}</strong>
              <button
                className="text-white bg-red-500 hover:bg-red-600 h-fit w-fit px-6 mt-5 py-1.5 rounded-xl"
                onClick={() => {
                  setSelectedFile(null);
                  setPreviewUrl(null);
                }}
              >
                Remove
              </button>
            </div>
          </div>
        ) : (
          <div
            onDragOver={handleDragOver}
            onDrop={handleDrop}
            className="rounded-xl border-dashed border-2 border-blue-500 sm:h-[400px] h-[200px] w-full flex items-center justify-center mt-8"
          >
            Drag and Drop file here or{" "}
            <label
              htmlFor="fileInput"
              className="ml-1 underline text-blue-500 cursor-pointer"
            >
              Choose file
            </label>
            <input
              id="fileInput"
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />
          </div>
        )}
      </div>
      {selectedFile && <div className="my-10 flex flex-col items-start w-full px-3">
        <input
          type="text"
          className="bg-[#f2f2f2] hover:bg-[#e4e4e7] outline-none border-none rounded-xl px-4 h-11 text-sm sm:w-1/4 w-full"
          placeholder="File Name"
          value={fileName}
          onChange={(e) => setFileName(e.target.value)}
        />
        <button
          className="bg-green-600 text-white py-2 px-8 mt-3 rounded-xl hover:bg-green-700 transition"
          onClick={handleUpload}
        >
          Upload
        </button>
      </div>}
    </div>
  );
}
