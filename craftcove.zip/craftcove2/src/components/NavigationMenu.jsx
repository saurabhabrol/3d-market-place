import * as React from "react"

import { cn } from "@/lib/utils"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle
} from "@/components/ui/navigation-menu"
import { Link } from "react-router-dom"

const components = [
  {
    title: "Home Decorations",
    href: "/products/categories/Home?category=HomeDecorations",
    description:
      "Enhance your living space with our exquisite collection of home decorations."
  },
  {
    title: "Art",
    href: "/products/categories/Art",
    description: "Explore our captivating art pieces for enriching your surroundings."
  },
  {
    title: "Fashion",
    href: "/products/categories/Fashion",
    description:
      "Stay trendy with our fashionable clothing and accessories for all occasions."
  },
  {
    title: "Decorations",
    href: "/products/categories/Decorations",
    description: "Find decorative items to add flair and personality to any space."
  },
  {
    title: "Engineering",
    href: "/products/categories/Engineering",
    description:
      "Discover innovative engineering solutions designed to meet your needs."
  },
];


export function NavbarNavigationMenu() {
  return (
    <NavigationMenu>
      <NavigationMenuList>
        <NavigationMenuItem>
          <NavigationMenuTrigger className="text-xl bg-transparent hover:bg-transparent">Categories</NavigationMenuTrigger>
          <NavigationMenuContent>
            <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px] ">
              {components.map(component => (
                <ListItem
                  key={component.title}
                  title={component.title}
                  href={component.href}
                >
                  {component.description}
                </ListItem>
              ))}
            </ul>
          </NavigationMenuContent>
        </NavigationMenuItem>
        <NavigationMenuItem>
          <Link to="/products/categories/Fashion">
            <NavigationMenuLink className={`${navigationMenuTriggerStyle()} text-xl bg-transparent hover:bg-transparent`} >
              Deals
            </NavigationMenuLink>
          </Link>
        </NavigationMenuItem>
      </NavigationMenuList>
    </NavigationMenu>
  )
}

const ListItem = React.forwardRef(
  ({ className, title, children, href, ...props }, ref) => {
    return (
      <li>
        <NavigationMenuLink asChild>
          <Link
            ref={ref}
            className={cn(
              "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
              className
            )}
            to={href}
          >
            <div className="text-sm font-medium leading-none">{title}</div>
            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
              {children}
            </p>
          </Link>
        </NavigationMenuLink>
      </li>
    )
  }
)
ListItem.displayName = "ListItem"
