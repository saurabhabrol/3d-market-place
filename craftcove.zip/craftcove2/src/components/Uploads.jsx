import Navbar from "./Navbar";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "./ui/button";
import React from "react";

export default function Uploads() {
  const [uploads, setUploads] = React.useState([]);
  const navigate = useNavigate();
  React.useEffect(() => {
    if (uploads.length === 0) {
      setUploads(JSON.parse(localStorage.getItem("uploads")) || []);
    }
    if (!localStorage.getItem("isLoggedIn")) {
      navigate("/login");
    }
  }, []);

  const handleDelete = (index) => {
    const updatedUploads = [...uploads];
    updatedUploads.splice(index, 1); // Remove the item at the given index
    setUploads(updatedUploads); // Update state
    localStorage.setItem("uploads", JSON.stringify(updatedUploads)); // Update local storage
  };
  return (
    <div>
      <Navbar />
      <div className="m-4">
        <strong className="text-3xl ">My uploads</strong>
      </div>
      {uploads.length === 0 && (
        <div className="w-full flex items-center justify-center flex-col min-h-[75vh]">
          <p className="font-bold text-xl">No File Uploads Availiable</p>
          <Link to={"/"}>
            <Button
              type="submit"
              className={"bg-green-800 hover:bg-green-900 mt-2"}
            >
              Explore
            </Button>
          </Link>
        </div>
      )}
      <div className="my-10 grid gap-5 xl:grid-cols-3 lg:grid-cols-2 md:grid-cols-2 grid-cols-1 px-3">
        {uploads.map((item, index) => {
          return (
            <div key={index}>
              <strong className="text-2xl">
                {index + 1}. {item.name}
              </strong>
              <img
                src={item.file}
                alt="Preview"
                className="h-[400px] aspect-square rounded-xl object-cover"
              />
              <button
                className="text-white bg-red-500 hover:bg-red-600 h-fit w-fit px-6 mt-5 py-1.5 rounded-xl"
                onClick={() => handleDelete(index)}
              >
                Delete
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
