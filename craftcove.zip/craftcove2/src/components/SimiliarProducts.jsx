import { products } from "@/assets/products";
import ProductItem from "./ProductItem";
import { useLocation, useParams } from "react-router-dom";

export default function SimiliarProducts() {
  const params = useParams();
  const search = useLocation().search;
  const queryParameters = new URLSearchParams(search);
  const currentCategory = queryParameters.get("category");

  // Filter products based on selected filter
  const filteredProducts = products.filter(
    (product) =>
      product.category === currentCategory &&
      params.productId !== product.id.toString()
  );

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {filteredProducts.map((product) => (
        <ProductItem product={product} fullProduct={product} key={product.id} />
      ))}
    </div>
  );
}
