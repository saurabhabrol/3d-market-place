import { products } from "@/assets/products";
import ProductItem from "./ProductItem";
import { useParams } from "react-router-dom";
import SaleBanner from "./SaleBanner";

export default function CategoryProduct() {
  const params = useParams();

  // Filter products based on selected filter
  const filteredProducts = products.filter(
    (product) => product.category === params.category
  );

  return (
    <div>
      <div className="mb-10">
      <SaleBanner/>
      </div>
      <strong className="text-3xl">{params.category} Products For You!</strong>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {filteredProducts.map((product) => (
          <ProductItem
            product={product}
            fullProduct={product}
            key={product.id}
          />
        ))}
      </div>
    </div>
  );
}
