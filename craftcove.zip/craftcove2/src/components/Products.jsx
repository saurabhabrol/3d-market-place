import { products } from "@/assets/products";
import ProductItem from "./ProductItem";
import { useFilter } from "@/context/FilterProvider";

export default function Products() {
  const { selectedFilter } = useFilter();

  // Filter products based on selected filter
  const filteredProducts =
    selectedFilter && selectedFilter !== "All"
      ? products.filter((product) => product.category === selectedFilter)
      : products;

  return (
    <div>
      <strong className="text-3xl">{selectedFilter !== "All" ? selectedFilter : ""} Product&apos;s For You!</strong>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-6">
        {filteredProducts.map((product) => (
          <ProductItem
            product={product}
            fullProduct={product}
            key={product.id}
          />
        ))}
      </div>
    </div>
  );
}
