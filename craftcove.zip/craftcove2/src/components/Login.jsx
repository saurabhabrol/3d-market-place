import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Login() {
  const [isVisible, setIsVisible] = useState(false);
  const toggleVisibility = () => setIsVisible(!isVisible);

  const [user_email, setUser_email] = useState("");
  const [user_password, setUser_password] = useState("");
  const [isInvalid, setIsInvalid] = useState({
    password: false,
    email: false,
  });

  //* router
  const navigate = useNavigate();

  //* verification
  const validateEmail = (user_email) =>
    user_email.match(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+.[A-Z]{2,4}$/i);

  const isInvalidEmail = React.useMemo(() => {
    if (user_email === "") return false;

    return validateEmail(user_email) ? false : true;
  }, [user_email]);

  // Handling Login
  const handleLogin = async (e) => {
    e.preventDefault();
    if (user_email === "") {
      setIsInvalid((prev) => ({
        ...prev,
        email: true,
      }));
      return;
    } else if (user_password === "") {
      setIsInvalid((prev) => ({
        ...prev,
        password: true,
      }));
      return;
    }
    try {
      const data = JSON.parse(localStorage.getItem("user"));
      if (!data) {
        setIsInvalid((prev) => ({
          ...prev,
          email: true,
        }));
        return;
      }
      if (data.email !== user_email) {
        setIsInvalid((prev) => ({
          ...prev,
          email: true,
        }));
      } else {
        if (data.password !== user_password) {
          console.log(true);
          setIsInvalid((prev) => ({
            ...prev,
            password: true,
          }));
        } else {
          localStorage.setItem("isLoggedIn", "true");
          navigate("/");
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  React.useEffect(() => {
    if (localStorage.getItem("isLoggedIn")) {
      navigate("/");
    }
  }, [navigate]);
  return (
    <div className="flex items-center justify-center flex-row-reverse">
      <div className="w-1/2 sm:block hidden">
        <img
          src="https://cdn.dribbble.com/users/2520294/screenshots/7269423/media/8db02365a1363822ae9f0554cf3d4469.gif"
          alt="not found"
          className="min-h-screen object-contain mix-blend-darken"
        />
      </div>

      <section className=" sm:w-1/2 w-full mt-10 sm:mt-0">
        <div className="flex flex-col items-center justify-center px-0 sm:px-6 py-8 mx-auto md:h-screen lg:py-0">
          <div className="flex items-center sm:text-2xl text-3xl font-semibold text-gray-900 dark:text-white absolute sm:left-10 left-6 top-5">
            CraftClove
          </div>
          <div className="w-full bg-white rounded-lg  dark:border md:mt-0 sm:max-w-md xl:p-0 dark:bg-gray-800 dark:border-gray-700">
            <div className="p-6 space-y-4 md:space-y-6 sm:p-8">
              <h1 className="text-2xl font-bold leading-tight tracking-tight text-gray-900 md:text-2xl dark:text-white">
                Sign in to your account
              </h1>
              <form className="space-y-4 md:space-y-6" onSubmit={handleLogin}>
                <div>
                  <label
                    htmlFor="email"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    Your email
                  </label>
                  <input
                    type="email"
                    name="email"
                    id="email"
                    value={user_email}
                    onChange={(e) => {
                      setUser_email(e.target.value);
                      setIsInvalid((prev) => ({
                        ...prev,
                        email: false,
                      }));
                    }}
                    className={`bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500`}
                    placeholder="name@company.com"
                    required=""
                  />
                  <div className="h-2">
                    {(isInvalidEmail || isInvalid.email) && (
                      <p className="text-xs text-red-500">Invalid email</p>
                    )}
                  </div>
                </div>
                <div>
                  <label
                    htmlFor="password"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    Password
                  </label>
                  <input
                    type={isVisible ? "text" : "password"}
                    name="password"
                    id="password"
                    placeholder="••••••••"
                    value={user_password}
                    onChange={(e) => {
                      setUser_password(e.target.value);
                      setIsInvalid((prev) => ({
                        ...prev,
                        password: false,
                      }));
                    }}
                    className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    required=""
                  />
                  <div className="h-2">
                    {isInvalid.password && (
                      <p className="text-xs text-red-500">Invalid password</p>
                    )}
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-start">
                    <div className="flex items-center h-5">
                      <input
                        id="showpass"
                        aria-describedby="showpass"
                        type="checkbox"
                        onChange={() => toggleVisibility()}
                        className="w-4 h-4 border border-gray-300 rounded bg-gray-50 focus:ring-3 focus:ring-primary-300 dark:bg-gray-700 dark:border-gray-600 dark:focus:ring-primary-600 dark:ring-offset-gray-800"
                        required=""
                      />
                    </div>
                    <div className="ml-3 text-sm">
                      <label
                        htmlFor="showpass"
                        className="text-gray-500 dark:text-gray-300"
                      >
                        show password
                      </label>
                    </div>
                  </div>
                </div>
                <div className="mt-5">
                  <button id="button" type="submit">
                    <span>Sign in</span>
                  </button>
                </div>
                <p className="text-sm font-light text-gray-500 dark:text-gray-400">
                  Don’t have an account yet?{" "}
                  <Link
                    to="/register"
                    className="font-medium text-blue-600 hover:underline dark:text-blue-500"
                  >
                    Sign up
                  </Link>
                </p>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
