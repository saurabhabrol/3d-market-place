import { Button } from "./ui/button";
import Navbar from "./Navbar";
import { Link, useNavigate } from "react-router-dom";
import React from "react";

export default function Orders() {
  const [totalSpent, setTotalSpent] = React.useState(0);
  const [items, setItems] = React.useState([]);
  const navigate = useNavigate();
  React.useEffect(() => {
    if (!localStorage.getItem("isLoggedIn")) {
      navigate("/login");
    }
    const items = JSON.parse(localStorage.getItem("orders"))?.items || [];
    const totalPrice = items.reduce((Vtotal, cartItems) => {
      const orderTotal = cartItems.reduce((total, item) => {
        return total + item.price * item.quantity;
      }, 0);
      return Vtotal + orderTotal;
    }, 0);
    setTotalSpent(totalPrice);
    setItems(items);
  }, []);
  return (
    <div>
      <Navbar />
      <div className="flex flex-col gap-10 m-5">
        <strong className="text-3xl ">My Orders</strong>
        {items.length === 0 ? (
          <div className="w-full flex items-center justify-center flex-col min-h-[70vh]">
            <p className="font-bold text-xl">No Orders Availiable</p>
            <Link to={"/"}>
              <Button
                type="submit"
                className={"bg-green-800 hover:bg-green-900 mt-2"}
              >
                Explore
              </Button>
            </Link>
          </div>
        ) : (
          items.map((cartItems, index) => {
            const orderTotal = cartItems.reduce((total, item) => {
              return total + item.price * item.quantity;
            }, 0);
            return (
              <div key={index}>
                <strong className="text-xl">Order #{index + 1}</strong>
                <div className="flex flex-col gap-3 mt-3">
                  {cartItems.map((item) => (
                    <CartItem product={item} key={item.id} />
                  ))}
                </div>
                <div className="mt-2 text-sm">
                  Total price:{" "}
                  <span className="font-semibold text-lg">
                    ${orderTotal.toFixed(2)}
                  </span>
                </div>
              </div>
            );
          })
        )}
        {items.length >=1 && <strong className="sm:text-3xl text-2xl">Total Spent: ${totalSpent.toFixed(2)}</strong>}
      </div>
    </div>
  );
}

const CartItem = ({ product }) => {
  const totalPrice = product?.price * product?.quantity;
  return (
    <div className="rounded-xl flex gap-4">
      <div>
        <img
          src={product?.image}
          alt={product.name}
          className="h-20 rounded-xl aspect-square object-cover"
        />
      </div>
      <div className="flex flex-col">
        <div>
          <strong>{product?.name}</strong>
          <p className="text-xs font-semibold text-neutral-500">
            Quantity: {product?.quantity}
          </p>
        </div>
        <span className="text-sm font-semibold">
          Price: ${totalPrice.toFixed(2)}
        </span>
      </div>
    </div>
  );
};
