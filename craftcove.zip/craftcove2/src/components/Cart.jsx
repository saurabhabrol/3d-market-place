import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetFooter,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useCart } from "@/context/Cart";
import { FaPlus } from "react-icons/fa6";
import { FiMinus } from "react-icons/fi";
import { IoMdCart } from "react-icons/io";
import { OrderPlaced } from "./OrderPlaced";
import { useNavigate } from "react-router-dom";

export function CartSheet() {
  const { cartItems, totalPrice, setIsCartOpen, isCartOpen } = useCart();
  const navigate = useNavigate();
  return (
    <Sheet open={isCartOpen} onOpenChange={(open) => setIsCartOpen(open)}>
      <SheetTrigger asChild>
        <Button variant="icon" className={"relative"}>
          <IoMdCart size={25} />
          <div className="absolute top-0 right-0 bg-[#003d29] text-white rounded-full px-1.5">
            {cartItems.length}
          </div>
        </Button>
      </SheetTrigger>
      <SheetContent className={"overflow-y-scroll"}>
        <SheetHeader>
          <SheetTitle>My Cart</SheetTitle>
        </SheetHeader>
        <div className="flex flex-col gap-6 py-5">
          {cartItems.length === 0 ? (
            <div className="w-full flex items-center justify-center flex-col h-full">
              <p className="font-bold text-xl">Cart is Empty</p>
                <Button
                  type="submit"
                  className={"bg-green-700 hover:bg-green-800 mt-2"}
                  onClick={()=>{
                    setIsCartOpen(false)
                    navigate('/')
                  }}
                >
                  Explore
                </Button>
            </div>
          ) : (
            cartItems.map((item) => <CartItem key={item.id} product={item} />)
          )}
        </div>
        {cartItems.length !== 0 && (
          <SheetFooter className={"sticky -bottom-6"}>
            <div className="flex flex-col w-full bg-white py-3">
              <div>
                <p className="font-semibold">
                  Total Price: ${totalPrice.toFixed(2)}
                </p>
              </div>
              <OrderPlaced />
            </div>
          </SheetFooter>
        )}
      </SheetContent>
    </Sheet>
  );
}

const CartItem = ({ product }) => {
  const totalPrice = product?.price * product?.quantity;
  const { removeItem, addItem } = useCart();
  return (
    <div className="rounded-xl flex gap-4">
      <div>
        <img
          src={product?.image}
          alt={product.name}
          className="h-20 rounded-xl aspect-square object-cover"
        />
      </div>
      <div className="flex flex-col justify-evenly">
        <div className="mb-2">
          <strong>{product?.name}</strong>
          <div className=" bg-[#dbdbdb] flex gap-3 rounded-full px-3 w-fit items-center select-none">
            <button>
              <FiMinus onClick={() => removeItem(product.id)} size={13} />
            </button>
            <span>{product.quantity}</span>
            <button>
              <FaPlus
                onClick={() =>
                  addItem(
                    product,
                    product.image,
                    product.quantity,
                    product.color
                  )
                }
                size={13}
              />
            </button>
          </div>
        </div>
        <p className="text-xs">
          ${product?.price} x {product?.quantity} =
          <span className="text-sm font-semibold">
            {" "}
            ${totalPrice.toFixed(2)}
          </span>
        </p>
      </div>
    </div>
  );
};
