import React from "react";
import RatingStars from "./RatingStars";
import { IoHeartOutline } from "react-icons/io5";
import { IoHeartSharp } from "react-icons/io5";
import { useCart } from "@/context/Cart";
import { Link } from "react-router-dom";
export default function ProductItem(props) {
  const [isLiked, setIsLiked] = React.useState(false);
  const { addItem, cartItems, removeItem } = useCart();

  const { price, description, id, name, rating, category, colors, image } =
    props.product;
  const productIsInCart = cartItems.find(
    (item) => item.id.toString() === id.toString()
  );

  return (
    <div className="group flex w-full max-w-xs flex-col overflow-hidden rounded-xl bg-white shadow-green-900 hover:shadow-2xl transition">
      <Link
        className="relative mx-3 mt-3 flex h-60 overflow-hidden rounded-xl"
        to={`/products/${id}?product=${name}&category=${category}&image=${image}`}
      >
        <div className="h-full w-full aspect-square">
          <img
            className=" h-full w-full object-cover group-hover:scale-110 transition"
            src={image}
            alt="product image"
          />
        </div>
        <div
          className="absolute top-3 left-3 bg-white rounded-full p-1.5"
          onClick={(event) => {
            event.preventDefault();
            setIsLiked((prev) => !prev);
          }}
        >
          {isLiked ? <IoHeartSharp color="red" /> : <IoHeartOutline />}
        </div>
      </Link>
      <div className="mt-4 px-5 pb-5">
        <div className="flex justify-between">
          <h4 className="text-lg tracking-tight text-slate-900">{name}</h4>
          <span className="text-xl font-bold text-slate-900">
            <span className="text-xs">$</span>
            {price}
          </span>
        </div>
        <p className="text-xs mt-1">
          {description.length < 35
            ? description
            : `${description.slice(0, 30)} ...`}
        </p>
        <div className="mt-2 mb-5 flex gap-1">
          <RatingStars value={rating} /> <span className="text-xs">(121)</span>
        </div>
        {productIsInCart ? (
          <button
            className="flex items-center justify-center rounded-full px-10 py-3.5 text-center text-sm font-medium text-white bg-[#003d29]"
            onClick={() => removeItem(id)}
          >
            Remove
          </button>
        ) : (
          <button
            className="flex items-center justify-center rounded-full  px-5 py-2.5 text-center text-sm font-medium hover:text-white hover:bg-[#003d29] border-2 border-[#003d29]  focus:outline-none focus:ring-4 focus:ring-blue-300 transition-all"
            onClick={() => {
              addItem(props.product, image, 1, colors ? colors[0] : "white");
            }}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="mr-2 h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"
              />
            </svg>
            Add to cart
          </button>
        )}
      </div>
    </div>
  );
}
