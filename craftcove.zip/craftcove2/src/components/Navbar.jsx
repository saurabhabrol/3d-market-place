import { NavbarNavigationMenu } from "./NavigationMenu";
import { ProfileDropDown } from "./ProfileDropdown";
import { CartSheet } from "./Cart";
import { Link, useNavigate } from "react-router-dom";

export default function Navbar() {
  const isLoggedIn = JSON.parse(localStorage.getItem("isLoggedIn"));
  const navigate = useNavigate();
  return (
    <nav className="flex items-center py-4 justify-between px-2 sm:px-20 border-b-2 border-green-600">
      <div className="flex items-center gap-2 sm:gap-16">
        <Link to="/" className="text-2xl mb-1">
          <strong>
            <span className="text-3xl text-green-600 mr-0.5">C</span>raftclove
          </strong>
        </Link>
        <div className="sm:block hidden">
          <NavbarNavigationMenu />
        </div>
      </div>
      <div className="flex items-center gap-2 sm:gap-5">
        <CartSheet />

        {isLoggedIn ? (
          <ProfileDropDown />
        ) : (
          <button
            className="font-normal bg-green-800 hover:bg-green-900 rounded-xl text-white py-2 sm:px-8 px-4 transition"
            onClick={() => navigate("/login")}
          >
            Login
          </button>
        )}
      </div>
    </nav>
  );
}
