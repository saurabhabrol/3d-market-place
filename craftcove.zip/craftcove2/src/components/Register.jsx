import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Login() {
  const [isVisible, setIsVisible] = useState(false);
  const toggleVisibility = () => setIsVisible(!isVisible);
  const [alreadyExists, setAlreadyExists] = useState(false);
  const [user_name, setUser_name] = useState();
  const [user_email, setUser_email] = useState("");
  const [user_password, setUser_password] = useState("");
  const [isInvalid, setIsInvalid] = useState({
    password: false,
    email: false,
  });

  //* router
  const navigate = useNavigate();

  //* verification
  const validateEmail = (user_email) =>
    user_email.match(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+.[A-Z]{2,4}$/i);

  const isInvalidEmail = React.useMemo(() => {
    if (user_email === "") return false;
    setAlreadyExists(false);
    return validateEmail(user_email) ? false : true;
  }, [user_email]);

  // Handling Login
  const handleLogin = async (e) => {
    e.preventDefault();
    if (user_email === "") {
      setIsInvalid((prev) => ({
        ...prev,
        email: true,
      }));
      return;
    } else if (user_password === "") {
      setIsInvalid((prev) => ({
        ...prev,
        password: true,
      }));
      return;
    }
    try {
      const data = JSON.parse(localStorage.getItem("user"));
      if (data && data.email === user_email) {
        setAlreadyExists(true);
      } else {
        const data = {
          name: user_name,
          email: user_email,
          password: user_password,
          about:
            "An artist of considerable range, Jenna the name taken by Melbourne-raised, Brooklyn-based Nick Murphy writes, performs and records all of his own music, giving it a warm, intimate feel with a solid groove structure. An artist of considerable range.",
        };
        localStorage.setItem("user", JSON.stringify(data));
        navigate("/login");
      }
    } catch (error) {
      console.log(error);
    }
  };

  React.useEffect(() => {
    if (localStorage.getItem("isLoggedIn")) {
      navigate("/");
    }
  }, [navigate]);
  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="w-1/2 hidden  h-full sm:flex items-center justify-center">
        <img
          src="https://cdn.goodmanlantern.com/wp-content/uploads/2022/04/Group-6631.svg"
          alt="not found"
          className="min-h-[70vh] hidden sm:block"
        />
      </div>
      <section className="sm:w-1/2 w-full sm:mt-0 mt-6">
        <div className="flex items-center sm:text-2xl text-3xl font-semibold text-gray-900 dark:text-white absolute top-5 sm:left-10 left-6">
          CraftClove
        </div>
        <div className="flex flex-col items-center justify-center sm:px-6 px-0 py-8 mx-auto md:h-screen lg:py-0">
          <div className="w-full bg-white rounded-lg dark:border md:mt-0 sm:max-w-md xl:p-0 dark:bg-gray-800 dark:border-gray-700">
            <div className="p-6 space-y-4 md:space-y-6 sm:p-8">
              <h1 className="text-xl font-bold leading-tight tracking-tight text-gray-900 md:text-2xl dark:text-white">
                Create new account
              </h1>
              <form className="space-y-4 md:space-y-6" onSubmit={handleLogin}>
                <div>
                  <label
                    htmlFor="name"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    Name
                  </label>
                  <input
                    type="text"
                    name="name"
                    id="name"
                    value={user_name}
                    onChange={(e) => setUser_name(e.target.value)}
                    className={`bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500`}
                    placeholder="Jhon doe"
                    required=""
                  />
                </div>
                <div>
                  <label
                    htmlFor="email"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    Your email
                  </label>
                  <input
                    type="email"
                    name="email"
                    id="email"
                    value={user_email}
                    onChange={(e) => setUser_email(e.target.value)}
                    className={`bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500`}
                    placeholder="name@company.com"
                    required=""
                  />
                  <div className="h-2">
                    {(isInvalidEmail || isInvalid.email) && (
                      <p className="text-xs text-red-500">Invalid email</p>
                    )}
                    {alreadyExists && (
                      <p className="text-xs text-red-500">
                        Email Already exists
                      </p>
                    )}
                  </div>
                </div>
                <div>
                  <label
                    htmlFor="password"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    Password
                  </label>
                  <input
                    type={isVisible ? "text" : "password"}
                    name="password"
                    id="password"
                    placeholder="••••••••"
                    value={user_password}
                    onChange={(e) => setUser_password(e.target.value)}
                    className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    required=""
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-start">
                    <div className="flex items-center h-5">
                      <input
                        id="showpass"
                        aria-describedby="showpass"
                        type="checkbox"
                        onChange={() => toggleVisibility()}
                        className="w-4 h-4 border border-gray-300 rounded bg-gray-50 focus:ring-3 focus:ring-primary-300 dark:bg-gray-700 dark:border-gray-600 dark:focus:ring-primary-600 dark:ring-offset-gray-800"
                        required=""
                      />
                    </div>
                    <div className="ml-3 text-sm">
                      <label
                        htmlFor="showpass"
                        className="text-gray-500 dark:text-gray-300"
                      >
                        show password
                      </label>
                    </div>
                  </div>
                </div>
                <div className="mt-5">
                  <button id="button" type="submit">
                    <span>Register</span>
                  </button>
                </div>
                <p className="text-sm font-light text-gray-500 dark:text-gray-400">
                  Already have an account?{" "}
                  <Link
                    to="/login"
                    className="font-medium text-blue-600 hover:underline dark:text-blue-500"
                  >
                    Sign in
                  </Link>
                </p>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
