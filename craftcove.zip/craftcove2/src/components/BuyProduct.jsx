import { products } from "@/assets/products";
import React from "react";
import { useParams } from "react-router";
import { useLocation } from "react-router-dom";
import RatingStars from "./RatingStars";
import { FiMinus } from "react-icons/fi";
import { FaPlus } from "react-icons/fa6";
import { CiDeliveryTruck } from "react-icons/ci";
import { IoIosCalendar } from "react-icons/io";
import { useCart } from "@/context/Cart";

import { FaCheckDouble } from "react-icons/fa6";
import SimiliarProducts from "./SimiliarProducts";
import NavigateProducts from "./NavigateProducts";

export default function BuyProduct() {
  const params = useParams();
  const search = useLocation().search;
  const queryParameters = new URLSearchParams(search);
  const productImage = queryParameters.get("image");

  const product = products.find(
    (product) => product.id.toString() === params.productId
  );

  // states
  const [selectedColor, setSelectedColor] = React.useState(
    product?.colors ? product?.colors[0] : null
  );
  const { cartItems, addItem, removeItem, setIsCartOpen } = useCart();

  const productIsInCart = cartItems.find(
    (item) => item.id.toString() === product.id.toString()
  );
  const handleAddProduct = () => {
    addItem(product, productImage, selectedColor);
  };
  const totalPrice = productIsInCart?.quantity * product?.price;
  if (!product) return <NavigateProducts />;
  return (
    <div className="pb-10">
      <p className="text-neutral-400">
        {product?.category} /{" "}
        <span className="text-black font-semibold">{product?.name}</span>
      </p>
      <div className="flex mt-5 gap-6 sm:gap-20 sm:flex-row flex-col">
        <div className="w-full h-1/2 sm:w-1/2">
          <img
            src={productImage}
            alt={product?.name}
            className="rounded-xl object-cover h-full w-full aspect-square"
          />
        </div>
        <div className="flex flex-col sm:w-1/2">
          <h1 className="text-4xl font-bold">{product?.name}</h1>
          <p className="text-sm font-medium mt-5">{product?.description}</p>

          <div className="mt-5 flex text-xs gap-1 pb-10 ">
            <RatingStars value={product?.rating} /> (121)
          </div>

          <div className="border-y-[2px] w-full py-6">
            <h2 className="text-2xl font-bold">${product?.price}</h2>
            <p>Suggested payments with 6 months special financing</p>
          </div>

          {product.colors && (
            <div className="border-b-[2px] w-full py-6">
              <strong className="text-xl font-bold">Choose a Color</strong>
              <div className="flex gap-4 mt-2">
                {product?.colors?.map((color, index) => (
                  <div
                    key={index}
                    style={{ backgroundColor: color.toLowerCase() }}
                    className={`${
                      selectedColor === color ? "border-2 border-black" : ""
                    } h-8 w-8 rounded-full cursor-pointer`}
                    onClick={() => setSelectedColor(color)}
                  ></div>
                ))}
              </div>
            </div>
          )}

          <div className="mt-6 bg-[#dbdbdb] flex gap-6 rounded-full px-6 py-2 w-fit items-center select-none">
            <button
              disabled={productIsInCart ? productIsInCart.quantity < 1 : true}
            >
              <FiMinus
                color={
                  productIsInCart
                    ? productIsInCart.quantity < 1
                      ? "gray"
                      : "black"
                    : "gray"
                }
                onClick={() => removeItem(product.id)}
              />
            </button>
            <span>{productIsInCart ? productIsInCart.quantity : 0}</span>
            <button>
              <FaPlus
                onClick={() =>
                  addItem(
                    product,
                    productImage,
                    product.colors ? product.colors[0] : "black"
                  )
                }
              />
            </button>
          </div>
          <div className="flex mt-6 gap-6 select-none sm:flex-row flex-col">
            <button
              className="rounded-full bg-[#113f30] text-white px-16 py-3 hover:bg-[#123226] hover:shadow-2xl transition"
              onClick={() => {
                if (!productIsInCart) {
                  addItem(
                    product,
                    productImage,
                    product.colors ? product.colors[0] : "black"
                  );
                }
                setIsCartOpen((prev) => !prev);
              }}
            >
              Buy Now {productIsInCart && `$${totalPrice.toFixed(2)}`}
            </button>

            <button
              className="py-2 px-12 border-2 border-[#003d29] rounded-full font-medium"
              onClick={handleAddProduct}
              disabled={productIsInCart}
            >
              {productIsInCart ? (
                <div className="flex items-center gap-2 w-full justify-center">
                  Added <FaCheckDouble size={15} />
                </div>
              ) : (
                "Add to Cart"
              )}
            </button>
          </div>
          <div className="mt-10 border-2 rounded-xl">
            <div className="p-3 border-b">
              <div className="flex items-center">
                <CiDeliveryTruck size={25} color="orange" />
                <strong className="ml-2">Free Delivery</strong>
              </div>
              <p className="ml-8 underline">
                Enter your Postal code for Delivery Availability
              </p>
            </div>
            <div className=" p-3">
              <div className="flex items-center">
                <IoIosCalendar size={20} color="orange" />
                <strong className="ml-2">Return Delivery</strong>
              </div>
              <p className="ml-7">
                Free 30days Delivery Returns.{" "}
                <span className="underline">Details</span>
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className="mt-10">
        <strong className="text-xl sm:text-3xl">
          More &quot;{product.category}&quot; products!!{" "}
        </strong>
        <SimiliarProducts />
      </div>
    </div>
  );
}
