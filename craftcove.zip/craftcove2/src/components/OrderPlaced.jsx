import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import { DollarSign } from "lucide-react";
import checkImage from "../assets/checkImage.jpg";
import { Link, useNavigate } from "react-router-dom";
import { useCart } from "@/context/Cart";

export function OrderPlaced() {
  const { setIsCartOpen, setCartItems, setTotalPrice, cartItems } = useCart();
  const navigate = useNavigate();
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button
          type="submit"
          className={"bg-green-600 hover:bg-green-700 w-full"}
          onClick={() => {
            if (!localStorage.getItem("isLoggedIn")) {
              navigate("/login");
            } else {
              const prevOrders =
                JSON.parse(localStorage.getItem("orders"))?.items || [];
              localStorage.setItem(
                "orders",
                JSON.stringify({
                  user: JSON.parse(localStorage.getItem("user"))?.email,
                  items: [...prevOrders, cartItems],
                })
              );
            }
          }}
        >
          <DollarSign size={20} />
          Checkout
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <img src={checkImage} alt="not found" />
        <div className="flex flex-col items-center justify-center">
          <strong className="text-2xl mb-2">Order Has Been Placed</strong>
          <p className="text-sm mb-1">Transaction Id: 254923492498</p>
          <Link to="/">
            <DialogClose asChild>
              <div
                className={
                  "bg-green-500 hover:bg-green-600 flex items-center text-white justify-center rounded-full py-2 w-fit px-8 cursor-pointer"
                }
                onClick={() => {
                  setCartItems([]);
                  setTotalPrice(0.0);
                  setIsCartOpen((prev) => !prev);
                }}
              >
                Continue shopping
              </div>
            </DialogClose>
          </Link>
        </div>
      </DialogContent>
    </Dialog>
  );
}
