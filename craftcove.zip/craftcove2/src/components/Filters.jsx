import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import React from "react";
import { useFilter } from "@/context/FilterProvider";
import NavSearchBar from "./NavSearchBar";

const filters = ["All", "Art", "Home", "Fashion", "Decorations", "Engineering"];

export default function Filters() {
  const { selectedFilter, setSelectedFilter } = useFilter();
  return (
    <div className="flex items-center gap-6 sm:flex-row flex-col">
      <div className="flex gap-2">
        {filters.slice(0, 3).map((item, index) => {
          return (
            <Badge
              onClick={() => setSelectedFilter(item)}
              key={`${item}${index}`}
              className={`px-7 py-3 ${
                selectedFilter == item
                  ? "bg-[#003d29] text-white"
                  : "bg-[#e7e6e6] hover:bg-[#d6d6d6] text-black"
              }    font-medium cursor-pointer`}
            >
              {item}
            </Badge>
          );
        })}
      </div>
      <AllFilters
        selectedFilter={selectedFilter}
        setSelectedFilter={setSelectedFilter}
      />
      <NavSearchBar/>
    </div>
  );
}

export function AllFilters(props) {
  return (
    <Select
      onValueChange={(item) => props.setSelectedFilter(item)}
      value={props.selectedFilter}
    >
      <SelectTrigger className="w-[150px] rounded-full bg-[#e7e6e6] hover:bg-[#d6d6d6]">
        <SelectValue placeholder="All Filters" />
      </SelectTrigger>
      <SelectContent>
        <SelectGroup>
          <SelectLabel>All Filters</SelectLabel>
          {filters.slice().map((item, index) => {
            return (
              <SelectItem key={`${item}${index}`} value={item}>
                {item}
              </SelectItem>
            );
          })}
        </SelectGroup>
      </SelectContent>
    </Select>
  );
}
