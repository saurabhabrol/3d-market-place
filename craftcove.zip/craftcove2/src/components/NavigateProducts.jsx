import { Link, Navigate, useLocation } from "react-router-dom";
import ProductItem from "./ProductItem";
import { products } from "@/assets/products";
import { GoArrowLeft } from "react-icons/go";
import NavSearchBar from "./NavSearchBar";
import React from "react";

export default function NavigateProducts() {
  const search = useLocation().search;
  const queryParameters = new URLSearchParams(search);
  const location = useLocation();
  const searchQuery = queryParameters.get("query");
  React.useEffect(() => {
    window.scrollTo(0,0)
  }, [])
  
  if (searchQuery) {
    // Filter products based on selected filter
    let filteredProducts = products.filter((product) => {
      let name = product.name.toLowerCase();
      return name.includes(searchQuery.toLowerCase());
    });

    if (filteredProducts.length <= 1) {
      const matchedProduct = filteredProducts[0];
      // Filter other products with the same category
      const similarProducts = products.filter(
        (item) =>
          item.category === matchedProduct.category &&
          matchedProduct.id.toString() !== item.id.toString()
      );

      // Concatenate the similar products to the filtered products array
      filteredProducts.push(...similarProducts);
    }
    // Check if we can navigate back
    const canGoBack = location.key !== "default";
    const prevHref = canGoBack ? -1 : "/";
    return (
      <div>
        <div className="my-7 relative w-fit flex items-center gap-8">
          <Link to={prevHref}>
            <button className=" rounded-full bg-green-800 px-5 py-2.5 text-white flex items-center gap-1">
              <GoArrowLeft /> Back
            </button>
          </Link>
          <NavSearchBar />
        </div>
        <strong className="text-3xl">
          Products related to &apos;{searchQuery}&apos;
        </strong>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <ProductItem
              product={product}
              fullProduct={product}
              key={product.id}
            />
          ))}
        </div>
      </div>
    );
  } else {
    return <Navigate to="/" replace={true} />;
  }
}
