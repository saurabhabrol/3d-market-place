import { Link } from "react-router-dom";
import headphones from "../assets/bannerImage.png";
export default function SaleBanner() {
  return (
    <div className="bg-[#fbf0e4] flex items-center sm:flex-row flex-col sm:h-[300px] justify-between sm:px-16 px-2 overflow-hidden rounded-md py-2">
      <div>
        <h2 className="sm:text-5xl text-2xl sm:w-3/4 mb-5 text-[#11321d] font-semibold">
          Grab Upto 50% Off On Fashion Products
        </h2>
        <Link to="/products/categories/Fashion">
          <button className="rounded-full bg-[#003d29] text-white px-7 py-2 sm:w-fit w-full">
            Buy Now
          </button>
        </Link>
      </div>
      <div className="h-full items-center hidden sm:flex">
        <img src={headphones} alt="headphones" className="" />
      </div>
    </div>
  );
}
